██████╗░██╗░░░██╗░██████╗███████╗███████╗████████╗░█████╗░██████╗░████████╗
██╔══██╗██║░░░██║██╔════╝██╔════╝██╔════╝╚══██╔══╝██╔══██╗██╔══██╗╚══██╔══╝
██████╦╝██║░░░██║╚█████╗░█████╗░░█████╗░░░░░██║░░░███████║██████╦╝░░░██║░░░
██╔══██╗██║░░░██║░╚═══██╗██╔══╝░░██╔══╝░░░░░██║░░░██╔══██║██╔══██╗░░░██║░░░
██████╦╝╚██████╔╝██████╔╝███████╗███████╗░░░██║░░░██║░░██║██████╦╝░░░██║░░░
╚═════╝░░╚═════╝░╚═════╝░╚══════╝╚══════╝░░░╚═╝░░░╚═╝░░╚═╝╚═════╝░░░░╚═╝░░░

                       BLUESTART - By Ehqie 💻
                   -------------------------------
                   Version : V1.0
                   Langue  : Français 🇫🇷
                   Type    : Tool Windows (.bat)
                   Auteur  : ehqie
                   -------------------------------


📄 DESCRIPTION
--------------
BlueStart est un outil multifonction puissant conçu pour Windows.
Il te permet d’automatiser des tâches utiles du quotidien :
  - Lancer des logiciels, jeux ou outils
  - Ouvrir des sites utiles, services OSINT, réseaux sociaux
  - Nettoyer ton PC rapidement
  - Voir / réparer ta connexion réseau
  - Sauvegarder tes fichiers importants
  - Customiser ton terminal
  - Gérer tes fichiers / processus
  - Et même afficher des effets comme Matrix 💻🟩

🎯 L’objectif : Tout centraliser, stylé, et rapide.

📂 STRUCTURE DU DOSSIER
------------------------
📁 BlueStart/
├── main.bat           → Le fichier principal (à lancer)
├── README.txt         → Ce fichier, contenant la doc
├── files/             → Contient les exécutables, raccourcis ou scripts à lancer (autoclicker.exe, etc.)

⚙️ PRÉREQUIS
-------------
- Windows 10 ou 11
- Invite de commandes (CMD)
- Accès administrateur recommandé pour certaines options
- Accès Internet pour les options web (OSINT, liens)

✅ COMPATIBILITÉ TESTÉE
------------------------
✔️ Windows 10 64 bits  
✔️ Windows 11  
✔️ Invite de commande standard (CMD)  
✔️ Fonctionne sans installer autre chose

🔐 AVERTISSEMENT
-----------------
Ce tool est développé par **ehqie**.

⛔️ Ne pas modifier, copier ou revendre ce code sans autorisation.  
❌ Toute modification du script est à vos risques.  
📬 En cas de bug ou question, contactez ehqie.

🛠️ Ce projet est en évolution constante, surveille les prochaines versions !

---

Merci d’utiliser BlueStart.
T’es officiellement dans le turfu. 🚀

